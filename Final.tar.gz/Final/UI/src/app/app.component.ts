import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { RouterService } from './services/router.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  ngOnInit() {
   // this.routerService.routeToLogin();

  this.routerService.navigate(['login']) ;
  }
  constructor(private routerService: Router) { }
}
