import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Note } from '../note';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { AuthenticationService } from '../services/authentication.service';

const API_URL = environment.apiUrl;
@Injectable()
export class NotesService {

  constructor(private _http: HttpClient, private authenticationService: AuthenticationService) {

  }
  getNotes(): Observable<Array<Note>> {
    if (this.authenticationService.
      isUserAuthenticated(this.authenticationService.getBearerToken())) {
      const httpOptions = {
        headers: new HttpHeaders({
          Authorization: `Bearer ${
            this.authenticationService.getBearerToken()}`
        })
      };
      return this._http.get(API_URL + '/api/v1/note/', httpOptions)
        .map(data => {
          if (data) {
            return data;
          }

        }).catch(this.handleError);
    }
  }

  addNote(note: Note): Observable<Note> {
    if (this.authenticationService.
      isUserAuthenticated(this.authenticationService.getBearerToken())) {
      const httpOptions = {
        headers: new HttpHeaders({
          Authorization: `Bearer ${
            this.authenticationService.getBearerToken()}`
        })
      };
      return this._http
        .post(API_URL + '/api/v1/note', note, httpOptions)
        .map(data => {
          if (data) {
          }
          return data;
        }).catch(this.handleError);
    }
  }
  private handleError(error: HttpErrorResponse | any) {
    console.error('ApiService::handleError', error);
    return Observable.throw(error);
  }
}
