import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';


@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    beartoken: any;
    loading = false;
    returnUrl: String;
    submitMessage: String;
    passwordRegex = '/^(?=.[A-Za-z])(?=.\d)[A-Za-z\d]{4,20}/';
    username = new FormControl('', [Validators.required, Validators.maxLength(15)]);
    password = new FormControl('', Validators.compose([Validators.required,
    Validators.minLength(4), Validators.maxLength(20), Validators.pattern(this.passwordRegex)]));
    dataArr = new FormGroup({ username: this.username, password: this.password });
    constructor(private authenticationService: AuthenticationService,
        private routerService: RouterService
    ) { }
    ngOnInit() {
    }
    loginSubmit() {
        this.loading = true;
        this.authenticationService.authenticateUser(this.dataArr)
            .subscribe(
                data => {
                    this.beartoken = data['token'];
                    this.authenticationService.setBearerToken(this.beartoken);
                    this.routerService.routeToDashboard();
                },
                (error) => {
                    if (error.status === 404) {
                        this.submitMessage = error.message;
                    }
                    if (error.status === 403) {
                        this.submitMessage = error.error.message;
                    }
                    this.loading = false;

                }

            );
    }
}
