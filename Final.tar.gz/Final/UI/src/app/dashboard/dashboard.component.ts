import { Component } from '@angular/core';
// { _catch } from 'rxjs/operator/catch';
import { MatTableDataSource } from '@angular/material';
import { OnInit } from '@angular/core';
import { NotesService } from '../services/notes.service';
import { Note } from '../note';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  errMessage: string;
  note = new Note();
  notes: Note[] = [];
  displayedColumns = ['title', 'text'];
  dataSource = new MatTableDataSource<Note>(this.notes);
  constructor(private notesservices: NotesService) { }
  ngOnInit() {
    this.loadInfo();
  }
  done() {
    if (typeof this.note.title === 'undefined' && typeof this.note.text === 'undefined') {
      this.errMessage = 'title and text are mandatory';
    } else if (typeof this.note.title === 'undefined') {
      this.errMessage = 'title are mandatory';


    } else if (typeof this.note.text === 'undefined') {
      this.errMessage = 'text are mandatory';
    } else {
      this.notesservices.addNote(this.note).subscribe(data => {
        if (data != null) {
          console.log('Success');
          this.loadInfo();
        }
      },
        err => {
          if (err.status === 404) {
            this.errMessage = 'Http failure response for http://localhost:3000/api/v1/notes: 404 Not Found';
          } else {
            this.errMessage = 'Unexpected error.please try later';
          }

        },
        () => console.log('Service was complete'));
    }
  }
  loadInfo() {
    this.notesservices.getNotes().subscribe(data => {
      if (data != null) {
        this.notes = data;

      }
    },
      err => {
        if (err.status === 404) {
          this.errMessage = 'Http failure response for http://localhost:3000/api/v1/notes: 404 Not Found';
        } else {
          this.errMessage = 'Unexpected error.please try later';
        }
      },
      () => console.log('Service was complete'));

  }
}
